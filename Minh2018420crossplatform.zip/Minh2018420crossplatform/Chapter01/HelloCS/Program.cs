﻿// See https://aka.ms/new-console-template for more information
using System;

Console.WriteLine("Hello, C# !");
int z = 3;
System.Console.WriteLine(z);