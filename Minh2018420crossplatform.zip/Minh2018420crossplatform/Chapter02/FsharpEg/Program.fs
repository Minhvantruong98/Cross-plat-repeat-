﻿// For more information see https://aka.ms/fsharp-console-apps
printfn "Hello from F#"
printfn "Hello this is F#"